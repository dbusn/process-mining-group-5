Main script: baseline_algo_combined.py
The training dataset: bpi2017_train.csv
The test dataset: bpi2017_test.csv
The validation dataset: bpi2017_val.csv

Please make sure all the dependencies are installed. You can do this by executing 'pip install -r requirements.txt' 
from your terminal.

Then run 'python tool_2.py'. The output file with predictions is called tool_2_predictions.csv.
